package com.example.PITime01.motorista;

import org.springframework.data.jpa.repository.JpaRepository;


public interface motoristaRepository extends JpaRepository<motorista,Long> {


}
