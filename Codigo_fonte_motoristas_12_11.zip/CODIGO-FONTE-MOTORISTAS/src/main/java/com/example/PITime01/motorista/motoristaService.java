package com.example.PITime01.motorista;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class motoristaService {
    @Autowired
    private motoristaRepository repo;

    public List<motorista> listAll(){
        return repo.findAll();
    }
    public void save(motorista motorista){
        repo.save(motorista);
    }

    public motorista get(Long id1){
        return repo.findById(id1).get();
    }

    public void delete(Long id1){
        repo.deleteById(id1);
    }

}