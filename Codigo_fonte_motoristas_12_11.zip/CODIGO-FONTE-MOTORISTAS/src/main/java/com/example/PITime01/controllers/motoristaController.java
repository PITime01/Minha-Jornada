package com.example.PITime01.controllers;


import com.example.PITime01.employee.EmployeeDTO;
import com.example.PITime01.motorista.Categoria_Habilitada;
import com.example.PITime01.motorista.Sindicato;
import com.example.PITime01.motorista.motorista;
import com.example.PITime01.motorista.motoristaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.List;

// TODO: Arrumar nome das paginas HTML
// TODO: PAGINAR A PAGINA DE LISTAGEM
// TODO: CRIAR UMA PASTA PROS HTMLS DE FUNCIONARIO
// TODO: Quebrar a navbar em um Thymeleaf.Fragment e usar ele nas outras paginas, para ter consistencia!
@Controller
public class motoristaController implements WebMvcConfigurer{

    @Autowired
    private motoristaService service;

    private final String viewFolder = "motorista/";
    @RequestMapping("/motorista/new")
    public String showNewClientForm(Model model){
        // TODO: Validar CPF la no HTML com Javascript antes de submeter o formulario!
        motorista motorista = new motorista();
        model.addAttribute("motorista", motorista);
        model.addAttribute("availableCategoria_Habilitada", Categoria_Habilitada.values());
        model.addAttribute("availableSindicato", Sindicato.values());
        return viewFolder+"new";
    }

    @RequestMapping("/motorista/list")

    public String showEditClientForm(Model model){
        List<motorista> listmotorista = service.listAll();
        model.addAttribute("listmotorista", listmotorista);


        return viewFolder+"list";

    }





    @RequestMapping(value ="motorista/save", method= RequestMethod.POST)
    public String savemotorista(@ModelAttribute("motorista") motorista motorista){
        service.save(motorista);
        return "redirect:/motorista/list";
    }


    @RequestMapping("/motorista/edit/{id1}")
    public String showEditClientForm(@PathVariable(name="id1") Long id1){
        ModelAndView mav=new ModelAndView("motorista/edit");
        motorista motorista=service.get(id1);
        mav.addObject("motorista",motorista);
        return viewFolder + "edit";
    }
    @RequestMapping("/motorista/delete/{id1}")
    public String deleteProduct(@PathVariable(name="id1") Long id1){
        service.delete(id1);
        return "redirect:/motorista/list";
    }
}
