package com.example.PITime01.motorista;

public enum Sindicato {
    N("B"),
    S("C"),
    SS("D");




    public final String label;

    Sindicato(String label) {
        this.label = label;
    }}