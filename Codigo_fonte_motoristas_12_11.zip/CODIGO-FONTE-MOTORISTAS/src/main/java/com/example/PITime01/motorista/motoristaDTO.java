package com.example.PITime01.motorista;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 class UserDTO is used to publicly expose data stored in the database
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class motoristaDTO {
    private long id1;
    private String nome;
    private String sobrenome;
    private Categoria_Habilitada categoria_habilitada;
    private Integer ano_admissao;
    private Number telofone;
    private Sindicato sindicato;
    private String email;
}
