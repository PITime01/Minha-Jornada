package com.example.PITime01.motorista;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "motorista", schema = "springproject")
public class motorista {


    @Override
    public String toString() {
        return "motorista{" +
                "id1=" + id1 +
                ", nome='" + nome + '\'' +
                ", sobrenome='" + sobrenome + '\'' +
                ", categoria_habilitada=" + categoria_habilitada +
                ", ano_admissao=" + ano_admissao +
                ", telefone=" + telefone +
                ", sindicato=" + sindicato +
                ", email='" + email + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof motorista)) return false;
        motorista motorista = (motorista) o;
        return getId1() == motorista.getId1() &&
                getNome().equals(motorista.getNome()) &&
                getSobrenome().equals(motorista.getSobrenome()) &&
                getCategoria_habilitada() == motorista.getCategoria_habilitada() &&
                getAno_admissao().equals(motorista.getAno_admissao()) &&
                getTelefone().equals(motorista.getTelefone()) &&
                getSindicato() == motorista.getSindicato() &&
                getEmail().equals(motorista.getEmail());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId1(), getNome(), getSobrenome(), getCategoria_habilitada(), getAno_admissao(), getTelefone(), getSindicato(), getEmail());
    }

    public long getId1() {
        return id1;
    }

    public void setId1(long id1) {
        this.id1 = id1;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public Categoria_Habilitada getCategoria_habilitada() {
        return categoria_habilitada;
    }

    public void setCategoria_habilitada(Categoria_Habilitada categoria_habilitada) {
        this.categoria_habilitada = categoria_habilitada;
    }

    public Integer getAno_admissao() {
        return ano_admissao;
    }

    public void setAno_admissao(Integer ano_admissao) {
        this.ano_admissao = ano_admissao;
    }

    public Number getTelefone() {
        return telefone;
    }

    public void setTelefone(Number telefone) {
        this.telefone = telefone;
    }

    public Sindicato getSindicato() {
        return sindicato;
    }

    public void setSindicato(Sindicato sindicato) {
        this.sindicato = sindicato;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id1")
    private long id1;
    @Column(name="nome")
    private String nome;
    @Column(name="sobrenome")
    private String sobrenome;
    @Column(name="categoria_habilitada")
    @Enumerated(EnumType.STRING)
    private Categoria_Habilitada categoria_habilitada;
    @Column(name="ano_admissao")
    private Integer ano_admissao;
    @Column(name="telefone")
    private Number telefone;
    @Enumerated(EnumType.STRING)
    @Column(name="sindicato")
    private Sindicato sindicato;
    @Column(name="email")
    private String email;




}


