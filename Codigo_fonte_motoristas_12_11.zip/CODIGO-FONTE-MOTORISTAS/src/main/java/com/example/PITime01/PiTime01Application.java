package com.example.PITime01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class PiTime01Application {

	public static void main(String[] args) {
		SpringApplication.run(PiTime01Application.class, args);
	}

}
