package com.example.PITime01.motorista;

public enum Categoria_Habilitada {
    A("B"),
    B("C"),
    C("D");




    public final String label;

    Categoria_Habilitada(String label) {
        this.label = label;
    }
}
