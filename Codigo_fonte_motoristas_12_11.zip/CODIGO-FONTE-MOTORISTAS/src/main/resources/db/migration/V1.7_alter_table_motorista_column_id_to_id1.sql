ALTER TABLE motorista
   rename id to id1 ;