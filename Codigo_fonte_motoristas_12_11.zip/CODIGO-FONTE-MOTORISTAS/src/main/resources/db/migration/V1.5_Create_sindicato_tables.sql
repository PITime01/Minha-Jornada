create TABLE IF NOT EXISTS "sindicato" (
                                           "id" bigserial NOT NULL PRIMARY KEY,
                                           "sindicato" character varying (100) NOT NULL,
                                           "jornada" integer NOT NULL,
                                           "repouso" decimal(8,2) NOT NULL,
                                           "fracionar1" integer NOT NULL,
                                           "hora_alomoco" integer NOT NULL,
                                           "fracionar2" integer NOT NULL,
                                           "folga" decimal(8,2) NOT NULL,
                                           "fracionar3" integer NOT NULL,
                                           "he_permitida" integer,
                                           "banco_permitido" integer
);