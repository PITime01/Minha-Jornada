# Executando

```shell script
mvn clean verify install
```

```shell script
java -jar target/PITime01-0.0.1-SNAPSHOT.jar
```

Ou simplesmente 
```
mvn clean verify install && java -jar target/PITime01-0.0.1-SNAPSHOT.jar
```