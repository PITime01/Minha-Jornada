ALTER TABLE "user" ADD COLUMN "cpf" TEXT;
ALTER TABLE "user" ADD COLUMN "status" TEXT;
ALTER TABLE "user" ADD COLUMN "registration" TEXT;
ALTER TABLE "user" RENAME TO "employee";