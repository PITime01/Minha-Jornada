create TABLE IF NOT EXISTS "funcionarios" (
                                              "id" serial references employee (id) NOT NULL,
                                              "nome" character varying (100) NOT NULL,
                                              "sobrenome" character varying (100) NOT NULL,
                                              "funcao" character varying (100) NOT NULL,
                                              "ano_admissao" integer NOT NULL,
                                              "contato" numeric,
                                              "endereco" character varying (500),
                                              "setor" character varying (100)
);